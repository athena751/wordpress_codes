05.03.2016
- Version 1.0

07.04.2016
- Next Version 1.1
+ Update element Header of visual composer.

15.04.2016
- Next Version 1.2
+ Update element View Portfolio of visual composer : support post type slideshow,video & video html5

26.04.2016
- Next Version 1.2.1
+ Update element Category Slide

16.05.2016
- Next Version 1.3
+ Update element Header

06.07.2016
- Next Version 1.4
+ Update element View Post